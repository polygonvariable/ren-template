// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

// Engine Headers
#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "Components/SceneComponent.h"

// Project Headers
#include "RenEnvironmentFx/Public/EnvironmentBrushInterface.h"

// Generated Headers
#include "EnvironmentCanvasActor.generated.h"

// Forward Declarations
class AActor;
class USceneComponent;



/*
 * TODO:
 * Rename to EnvironmentBrushComponent
 * 
 */
UCLASS(ClassGroup = (Custom), Meta = (BlueprintSpawnableComponent))
class UEnvironmentBrushComponent : public USceneComponent, public IEnvironmentBrushInterface
{

	GENERATED_BODY()

public:

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bCanDraw = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector2D BrushSize = FVector2D(4.0f, 4.0f);


	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	TObjectPtr<UMaterialInterface> BrushMaterial;

	UPROPERTY()
	TObjectPtr<UMaterialInstanceDynamic> BrushMaterialInstance;


	virtual bool GetBrushDetails(FVector& Location, FVector2D& Size) override;
	virtual bool GetBrushDetails(FVector& Location, FVector2D& Size, UMaterialInstanceDynamic*& Material) override;


	UFUNCTION(BlueprintCallable)
	void SetBrushSize(FVector2D Size);

	UFUNCTION(BlueprintCallable)
	void SetCanDraw(bool bEnable);

};



/**
 * TODO:
 * Rename to EnvironmentCanvasActor
 * 
 */
UCLASS()
class AEnvironmentCanvasActor : public AActor
{

	GENERATED_BODY()

public:

	AEnvironmentCanvasActor();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

protected:

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float CanvasSize = 4096.0f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float ImageSize = 512.0f;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	float PixelRatio = 1.0f;



	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	TObjectPtr<UMaterialParameterCollection> MPC;

	UPROPERTY(EditAnywhere)
	TObjectPtr<UMaterialParameterCollectionInstance> MPCInstance;

	UPROPERTY(VisibleAnywhere)
	FVector2D PixelOffset;
	


	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	TObjectPtr<UTextureRenderTarget2D> MainRenderTarget;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	TObjectPtr<UTextureRenderTarget2D> PersistentRenderTarget;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	TObjectPtr<UMaterialInterface> DrawPersistentMaterial;

	UPROPERTY()
	TObjectPtr<UMaterialInstanceDynamic> DrawPersistentMaterialInstance;


	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	TObjectPtr<UMaterialInterface> DrawBrushMaterial;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	TObjectPtr<UMaterialInterface> DrawMainAdditiveMaterial;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	FName BrushTag = TEXT("EnvironmentBrush");

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	int MaxBrushes = 16;

	TArray<TWeakInterfacePtr<IEnvironmentBrushInterface>> BrushCollection;


	void FindBrushComponents();

	void RegisterBrush(AActor* Actor);
	void UnregisterBrush(AActor* Actor);


	void MoveRenderTargets();
	void DrawPersistentRenderTarget();
	void DrawMainRenderTarget();

};






/*
 * 
 * Environment Compute Brush Component
 *
 */
UCLASS(ClassGroup = (Custom), Meta = (BlueprintSpawnableComponent))
class UEnvironmentComputeBrush : public USceneComponent, public IEnvironmentBrushInterface
{

	GENERATED_BODY()

public:

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bCanDraw = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector2D BrushSize = FVector2D(4.0f, 4.0f);

	virtual bool GetBrushDetails(FVector& Location, FVector2D& Size) override;

};





/**
 * 
 * Environment Compute Canvas Actor
 *
 */
UCLASS()
class AEnvironmentComputeCanvas : public AActor
{

	GENERATED_BODY()

public:

	AEnvironmentComputeCanvas();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

protected:

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float CanvasSize = 4096.0f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float ImageSize = 512.0f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float ImageRatio = 1.0f;

	UPROPERTY(VisibleAnywhere)
	FVector2D PixelOffset;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	TObjectPtr<UMaterialParameterCollection> MPC;

	UPROPERTY(EditAnywhere)
	TObjectPtr<UMaterialParameterCollectionInstance> MPCInstance;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	FName BrushTag = TEXT("EnvironmentBrush");

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	int MaxBrushes = 16;

	TArray<TWeakInterfacePtr<IEnvironmentBrushInterface>> BrushCollection;


	void FindBrushComponents();

	void RegisterBrush(AActor* Actor);
	void UnregisterBrush(AActor* Actor);

	void MoveRenderTargets();
	void DrawPersistentRenderTarget();
	void DrawMainRenderTarget();

};

